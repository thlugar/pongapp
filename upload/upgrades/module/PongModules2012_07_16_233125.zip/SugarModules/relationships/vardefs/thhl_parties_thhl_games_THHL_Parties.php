<?php
// created: 2012-07-16 23:31:25
$dictionary["THHL_Parties"]["fields"]["thhl_parties_thhl_games"] = array (
  'name' => 'thhl_parties_thhl_games',
  'type' => 'link',
  'relationship' => 'thhl_parties_thhl_games',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_THHL_PARTIES_THHL_GAMES_FROM_THHL_GAMES_TITLE',
);
