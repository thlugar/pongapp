<?php
// created: 2012-07-16 23:31:25
$dictionary["Contact"]["fields"]["thhl_parties_contacts"] = array (
  'name' => 'thhl_parties_contacts',
  'type' => 'link',
  'relationship' => 'thhl_parties_contacts',
  'source' => 'non-db',
  'vname' => 'LBL_THHL_PARTIES_CONTACTS_FROM_THHL_PARTIES_TITLE',
);
