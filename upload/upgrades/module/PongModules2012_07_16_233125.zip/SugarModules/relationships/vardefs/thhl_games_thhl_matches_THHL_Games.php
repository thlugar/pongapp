<?php
// created: 2012-07-16 23:31:25
$dictionary["THHL_Games"]["fields"]["thhl_games_thhl_matches"] = array (
  'name' => 'thhl_games_thhl_matches',
  'type' => 'link',
  'relationship' => 'thhl_games_thhl_matches',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_THHL_GAMES_THHL_MATCHES_FROM_THHL_MATCHES_TITLE',
);
