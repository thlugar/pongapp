<?php
 // created: 2012-07-16 23:31:25
$layout_defs["THHL_Parties"]["subpanel_setup"]['thhl_parties_thhl_games'] = array (
  'order' => 100,
  'module' => 'THHL_Games',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_THHL_PARTIES_THHL_GAMES_FROM_THHL_GAMES_TITLE',
  'get_subpanel_data' => 'thhl_parties_thhl_games',
);
