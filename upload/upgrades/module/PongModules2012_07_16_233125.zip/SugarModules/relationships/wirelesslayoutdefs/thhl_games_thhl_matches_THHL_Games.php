<?php
 // created: 2012-07-16 23:31:25
$layout_defs["THHL_Games"]["subpanel_setup"]['thhl_games_thhl_matches'] = array (
  'order' => 100,
  'module' => 'THHL_Matches',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_THHL_GAMES_THHL_MATCHES_FROM_THHL_MATCHES_TITLE',
  'get_subpanel_data' => 'thhl_games_thhl_matches',
);
