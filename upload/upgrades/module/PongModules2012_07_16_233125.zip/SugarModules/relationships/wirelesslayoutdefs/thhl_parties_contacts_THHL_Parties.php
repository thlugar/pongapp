<?php
 // created: 2012-07-16 23:31:25
$layout_defs["THHL_Parties"]["subpanel_setup"]['thhl_parties_contacts'] = array (
  'order' => 100,
  'module' => 'Contacts',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_THHL_PARTIES_CONTACTS_FROM_CONTACTS_TITLE',
  'get_subpanel_data' => 'thhl_parties_contacts',
);
